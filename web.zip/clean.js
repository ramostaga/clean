const firebaseConfig = {
    apiKey: "AIzaSyCUgVFSvcZ7xiv80rWjONtcFCT3SIkdpHQ", // REQUIRED FOR FIREBASE AUTH
    authDomain: "test-2100d.firebaseapp.com",
    projectId: "test-2100d",
    databaseURL: "https://test-2100d-default-rtdb.europe-west1.firebasedatabase.app"
};
firebase.initializeApp(firebaseConfig);
const database = firebase.database();

const dataRef = database.ref('/'); // Replace 'users' with your desired path

function saveCache(str) { 
    try { window.AndroidNative.saveLocalCache(str); } 
    catch(e) { localStorage.setItem('clean_state_cache', str); } 
}
function loadCache() { 
    try { 
        let c = window.AndroidNative.loadLocalCache(); 
        if (c && c !== "null" && c !== "undefined" && typeof c === "string") return c; 
    } catch(e) {} 
    let lc = localStorage.getItem('clean_state_cache');
    if (lc && lc !== "null" && lc !== "undefined") return lc;
    return null;
}

let workState = { days: {} };

function saveWorkCache(str) {
    try { window.AndroidNative.saveWorkLocalCache(str); } catch(e) {}
    try { localStorage.setItem('clean_work_state_cache', str); } catch(e) {}
}

function loadWorkCache() {
    try {
        let c = window.AndroidNative.loadWorkLocalCache();
        if (c && c !== "null" && c !== "undefined" && typeof c === "string") return c;
    } catch(e) {}
    try {
        let lc = localStorage.getItem('clean_work_state_cache');
        if (lc && lc !== "null" && lc !== "undefined") return lc;
    } catch(e) {}
    return null;
}

function saveWorkState() {
    if (!workState) workState = { days: {} };
    if (!workState.days) workState.days = {};
    database.ref('workState/').set(workState);
    saveWorkCache(JSON.stringify(workState));
}

let show = 'cal';
let weekdays = document.getElementById('weekdays');
let state = {
    dListUp: [0],
    tListUp: [0],
    startDate: 1443394800000,
    mailsHistory: []
};
let dPersons = [];
let tPersons = [];
let savedDate;
let tsSavedDate;
let startDate = new Date(1443394800000);
let history = {};
let Panel;
let vacList = [];
let vaclen;
let toffList = [];
let tofflen;
let skipList = [];
let skiplen;
let tsPast;
let datePast;
let locked = true;
let firstAuthLoad = true;
firebase.auth().onAuthStateChanged(function(user) {
    if (user) {
        locked = false;
        if (firstAuthLoad) {
            firstAuthLoad = false;
            fetch2(); // Boot securely once token is verified
        } else if (show === 'edi' && document.getElementById('passForm')) {
            show = 'cal'; // Jump back to calendar after fresh successful login
            fetch2();
        }
    } else {
        locked = true;
        if (firstAuthLoad) {
            firstAuthLoad = false;
            if (loadCache()) {
                // If offline but previous cache exists, render the offline cache 
                // The subsequent Firebase read will quietly hit .catch() due to security rules
                fetch2(); 
            } else {
                // Absolute dead-stop on fresh unsanctioned installations
                schedule.innerHTML = '';
                weekdays.style.display = 'none';
                if (!navigator.onLine) {
                    schedule.innerHTML = '<div style="text-align: center; margin-top: 20vmin; font-size: 4vmin; color: var(--text-main);">❌ لا يوجد اتصال بالإنترنت<br><br><span style="font-size: 3vmin; opacity: 0.7;">يجب الاتصال بالإنترنت لتسجيل الدخول لأول مرة.</span></div>';
                    window.addEventListener('online', function() {
                       if (!firebase.auth().currentUser && !loadCache()) {
                           schedule.innerHTML = '';
                           firebaseLoginScreen();
                       }
                    }, { once: true });
                } else {
                    firebaseLoginScreen(); 
                }
            }
        }
    }
});
let monthName;
let calendar;
let lastMonth = {};
let schedule = document.getElementById('schedule');
const now = new Date();
const offset = now.getTimezoneOffset() * 60 * 1000;
const msDay = 24 * 60 * 60 * 1000;
const today = new Date().getDate();
const cmonth = (new Date().getMonth() + 1).toString().padStart(2, '0');

function nativeToast(msg) {
    if (window.AndroidNative) {
        window.AndroidNative.showToast(msg);
    } else {
        alert(msg);
    }
}

function clone(obj) {
    if (typeof structuredClone === 'function') return structuredClone(obj);
    return JSON.parse(JSON.stringify(obj));
}

function daysInMonth(month, year) {
    return new Date(year, month + 1, 0).getDate();
}

//shift type
function shiftType(date) {
    let sT = Math.floor(((date - startDate.getTime()) / msDay))
    if (sT >= 0) { return sT % 8 } else { return Math.abs(sT - 3) % 8 }
};

///////////////       render calendar      /////////////////
function renderCalendar(i) {
    // console.log("dPersons: " + dPersons);
    // console.log("tPersons: " + tPersons);
    let dList = clone(dPersons);
    let tList = clone(tPersons);
    let sList = clone(skipList);

    let month = new Date().getMonth() + i; // JavaScript months are 0-11
    let year = new Date().getFullYear();
    while (month > 11) {
        year++;
        month -= 12;
    };
    while (month < 0) {
        year--;
        month += 12;
    };
    // console.log('month: ' + month + 'year: ' + year);
    // console.log('i: '+i);
    //calendar
    let days = daysInMonth(month, year);

    let u = Math.floor((new Date(year, month, 1).getTime() - tsSavedDate) / msDay);
    if (u < 0) { u = 0 };
    // console.log("i: " + i)
    if ((u > 0)) {
        if (typeof (lastMonth[i - 1]) == 'undefined') {
            for (let j = 0; j < u; j++) {
                let checkDate = tsSavedDate + j * msDay
                if ((checkDate == tsPast)) { state.dListUp = clone(dList); state.tListUp = clone(tList); state.skipList = clone(sList); };
                if (shiftType(checkDate) < 4) {
                    let dvac = [];
                    let tvac = [];
                    for (let k = 0; k < vaclen; k++) {
                        let x = clone(vacList);
                        while (dList[0] === x[k].Name && checkDate >= x[k].vacDay && checkDate < x[k].vacDay + x[k].Days * msDay && (x[k].taskType == 'All' || x[k].taskType == 'Dishes')) { dvac.push(dList.shift()); k = 0; }
                        while (tList[0] === x[k].Name && checkDate >= x[k].vacDay && checkDate < x[k].vacDay + x[k].Days * msDay && (x[k].taskType == 'All' || x[k].taskType == 'Table')) { tvac.push(tList.shift()); k = 0; }
                    };
                    let skipDishesLoop = true;
                    while (skipDishesLoop && dList.length > 0) {
                        let sMatch = sList.findIndex(s => s.Name === dList[0] && (s.taskType === 'All' || s.taskType === 'Dishes') && checkDate >= s.skipDate);
                        if (sMatch !== -1) { sList.splice(sMatch, 1); dList.push(dList.shift()); } else { skipDishesLoop = false; }
                    }
                    let skipTableLoop = true;
                    while (skipTableLoop && tList.length > 0) {
                        let sMatch = sList.findIndex(s => s.Name === tList[0] && (s.taskType === 'All' || s.taskType === 'Table') && checkDate >= s.skipDate);
                        if (sMatch !== -1) { sList.splice(sMatch, 1); tList.push(tList.shift()); } else { skipTableLoop = false; }
                    }
                    if (state.mList) {
                        let md = state.mList.find(m => m.mDate === checkDate && (m.taskType === 'All' || m.taskType === 'Dishes'));
                        if (md) { let idx = dList.indexOf(md.Name); if (idx > -1) { dList.splice(idx, 1); dList.unshift(md.Name); } }
                        let mt = state.mList.find(m => m.mDate === checkDate && (m.taskType === 'All' || m.taskType === 'Table'));
                        if (mt) { let idx = tList.indexOf(mt.Name); if (idx > -1) { tList.splice(idx, 1); tList.unshift(mt.Name); } }
                    }
                    let isdtoff = 1;
                    let isttoff = 1;
                    // console.log('offlan: ' + tofflen);
                    for (let k = 0; k < tofflen; k++) {
                        let x = clone(toffList);
                        // console.log('xk: ' + x[k]);
                        if (checkDate == x[k].date && (x[k].task == 'All' || x[k].task == 'Dishes')) { isdtoff = 0; };
                        if (checkDate == x[k].date && (x[k].task == 'All' || x[k].task == 'Table')) { isttoff = 0; };
                    };
                    if (isdtoff == 1) { dList.push(dList.shift()) };
                    if (isttoff == 1) { tList.push(tList.shift()) };
                    dList.unshift(...dvac);
                    tList.unshift(...tvac);
                };
            };
        } else {
            dList = clone(lastMonth[i - 1][0]); tList = clone(lastMonth[i - 1][1]); sList = clone(lastMonth[i - 1][2] || state.skipList || []);
            // console.log('month start' + year + (month));
            ;
        };
    };
    // console.log(u);
    // console.log(month);
    // console.log(dList);
    // console.log(tList)

    let frag = document.createDocumentFragment();

    monthName = document.createElement('div');
    monthName.id = 'monthName' + i;
    monthName.className = 'monthName';
    monthName.innerText = new Date(year, month).toLocaleString('ar-DZ', { month: 'long', year: 'numeric' });
    frag.appendChild(monthName);

    calendar = document.createElement('div');
    calendar.className = 'calendar';
    calendar.id = 'calendar' + i;
    frag.appendChild(calendar);

    //order
    monthName.style.order = i;
    calendar.style.order = i;
    calendar.style.zIndex = 1;
    monthName.style.zIndex = 50 + i;

    //empty days
    let emptyDays1 = new Date(year, month, 1).getDay(); // Adjusting so that Sunday=0, Monday=1, ..., Saturday=6
    for (let j = 0; j < emptyDays1; j++) {
        let emptyDay1 = document.createElement('div');
        emptyDay1.className = 'day empty';
        calendar.appendChild(emptyDay1);
    }
    let cDate;
    // console.log('u=',u);
    for (let j = 1; j <= days; j++) {
        cDate = new Date(year, month, j);
        let tscDate = cDate.getTime();
        let shiftDay;
        shiftDay = document.createElement('div');
        shiftDay.id = `day-${i}-${j}`;
        if ((tscDate == tsPast)) { state.dListUp = clone(dList); state.tListUp = clone(tList); state.skipList = clone(sList); };
        if (shiftType(tscDate) < 4) {
            let shift;
            if (shiftType(tscDate) < 2) {
                shiftDay.className = 'day M'; shift = 'M';
            } else { shiftDay.className = 'day N'; shift = 'N'; }
            if (tscDate >= tsSavedDate) {
                let dvac = [];
                let tvac = [];
                for (let k = 0; k < vaclen; k++) {
                    let x = clone(vacList);
                    while (dList[0] === x[k].Name && tscDate >= x[k].vacDay && tscDate < x[k].vacDay + x[k].Days * msDay && (x[k].taskType == 'All' || x[k].taskType == 'Dishes')) { dvac.push(dList.shift()); k = 0; };
                    while (tList[0] === x[k].Name && tscDate >= x[k].vacDay && tscDate < x[k].vacDay + x[k].Days * msDay && (x[k].taskType == 'All' || x[k].taskType == 'Table')) { tvac.push(tList.shift()); k = 0; };
                };
                let extraD = sList.filter(s => (s.taskType === 'All' || s.taskType === 'Dishes') && s.skipDate === tscDate).map(s => s.Name);
                let extraT = sList.filter(s => (s.taskType === 'All' || s.taskType === 'Table') && s.skipDate === tscDate).map(s => s.Name);
                let skipDishesLoop = true;
                while (skipDishesLoop && dList.length > 0) {
                    let sMatch = sList.findIndex(s => s.Name === dList[0] && (s.taskType === 'All' || s.taskType === 'Dishes') && tscDate >= s.skipDate);
                    if (sMatch !== -1) { sList.splice(sMatch, 1); dList.push(dList.shift()); } else { skipDishesLoop = false; }
                }
                let skipTableLoop = true;
                while (skipTableLoop && tList.length > 0) {
                    let sMatch = sList.findIndex(s => s.Name === tList[0] && (s.taskType === 'All' || s.taskType === 'Table') && tscDate >= s.skipDate);
                    if (sMatch !== -1) { sList.splice(sMatch, 1); tList.push(tList.shift()); } else { skipTableLoop = false; }
                }

                shiftDay.innerHTML = '<b>' + j + ' ' + shift + '</b>';

                if (state.mList) {
                    let md = state.mList.find(m => m.mDate === tscDate && (m.taskType === 'All' || m.taskType === 'Dishes'));
                    if (md) { let idx = dList.indexOf(md.Name); if (idx > -1) { dList.splice(idx, 1); dList.unshift(md.Name); } }
                    let mt = state.mList.find(m => m.mDate === tscDate && (m.taskType === 'All' || m.taskType === 'Table'));
                    if (mt) { let idx = tList.indexOf(mt.Name); if (idx > -1) { tList.splice(idx, 1); tList.unshift(mt.Name); } }
                }
                let isdtoff = 1;
                let isttoff = 1;
                let customDText = '';
                let customTText = '';
                // console.log('offlan: ' + tofflen);
                for (let k = 0; k < tofflen; k++) {
                    let x = clone(toffList);
                    // console.log('xk: ' + JSON.stringify(x[k].date));
                    if (tscDate == x[k].date && (x[k].task == 'All' || x[k].task == 'Dishes')) {
                        isdtoff = 0;
                        if (x[k].customText) {
                            customDText = x[k].customText;
                        }
                        // console.log('dOff')
                    };
                    if (tscDate == x[k].date && (x[k].task == 'All' || x[k].task == 'Table')) {
                        isttoff = 0;
                        if (x[k].customText) {
                            customTText = x[k].customText;
                        }
                        // console.log('tOff')
                    };
                };
                if (isdtoff == 1) {
                    let nameDiv = document.createElement('div');
                    let allW = [dList[0], ...extraD].slice(0, 2);
                    if (allW.length > 1) { nameDiv.className = 'cycler'; nameDiv.innerHTML = `<span>${allW[0]}</span><span>${allW[1]}</span>`; } else { nameDiv.textContent = allW[0]; }
                    shiftDay.appendChild(nameDiv);
                    dList.push(dList.shift());
                } else {
                    shiftDay.innerHTML += '<div>' + (customDText || 'No Shift') + '</div>';
                };
                if (isttoff == 1) {
                    let nameDiv = document.createElement('div');
                    let allW = [tList[0], ...extraT].slice(0, 2);
                    if (allW.length > 1) { nameDiv.className = 'cycler'; nameDiv.innerHTML = `<span>${allW[0]}</span><span>${allW[1]}</span>`; } else { nameDiv.textContent = allW[0]; }
                    shiftDay.appendChild(nameDiv);
                    tList.push(tList.shift());
                } else {
                    shiftDay.innerHTML += '<div>' + (customTText || 'No Shift') + '</div>';
                };
                dList.unshift(...dvac);
                tList.unshift(...tvac);
            } else {
                if (tscDate in history) {
                    shiftDay.innerHTML = '<b>' + j + ' ' + shift + '</b>';
                    [history[tscDate][0], history[tscDate][1]].forEach(wStr => {
                        let wDiv = document.createElement('div');
                        if (wStr && wStr.includes && wStr.includes(' & ')) {
                            let parts = wStr.split(' & ');
                            wDiv.className = 'cycler'; wDiv.innerHTML = `<span>${parts[0]}</span><span>${parts[1]}</span>`;
                        } else { wDiv.textContent = wStr; }
                        shiftDay.appendChild(wDiv);
                    });
                } else { shiftDay.innerHTML = '<b>' + j + ' ' + shift + '</b>No shift'; };
            };
        } else {
            shiftDay.className = 'day off';
            shiftDay.innerHTML = '<b>' + j + '</b>Off';
        };
        calendar.appendChild(shiftDay);
        if (cDate.getDate() === today && cDate.getMonth() === new Date().getMonth() && cDate.getFullYear() === new Date().getFullYear()) {
            shiftDay.classList.add('current');
            shiftDay.id = 'current';
        };
    };
    let emptyDays2 = new Date(year, month, days).getDay();
    for (let j = emptyDays2 + 1; j <= 6; j++) {
        let emptyDay2 = document.createElement('div');
        emptyDay2.className = 'day empty';
        calendar.appendChild(emptyDay2);
    }
    if (cDate.getTime() > tsSavedDate && typeof (lastMonth[i]) == 'undefined') {
        lastMonth[i] = [clone(dList), clone(tList), clone(sList)];
        // console.log('lastMonth: '+month+JSON.stringify(lastMonth[i]));
    };
    schedule.appendChild(frag);
};

// CALCULATE WHO WORKS?
function whoWork(tswDate) {

    let dList = clone(dPersons);
    let tList = clone(tPersons);
    let sList = clone(skipList);
    let worker = [];

    // console.log(dList);
    // console.log(tList);


    let u = Math.floor((tswDate - tsSavedDate) / msDay);
    if (u < 0) { u = 0 };

    if ((tswDate >= tsSavedDate)) {
        for (let j = 0; j <= u; j++) {
            let checkDate = tsSavedDate + j * msDay;
            if (shiftType(checkDate) < 4) {
                let dvac = [];
                let tvac = [];
                for (let k = 0; k < vaclen; k++) {
                    let x = clone(vacList);
                    while (dList[0] === x[k].Name && checkDate >= x[k].vacDay && checkDate < x[k].vacDay + x[k].Days * msDay && (x[k].taskType == 'All' || x[k].taskType == 'Dishes')) { dvac.push(dList.shift()); k = 0; }
                    while (tList[0] === x[k].Name && checkDate >= x[k].vacDay && checkDate < x[k].vacDay + x[k].Days * msDay && (x[k].taskType == 'All' || x[k].taskType == 'Table')) { tvac.push(tList.shift()); k = 0; }
                };
                let extraD = sList.filter(s => (s.taskType === 'All' || s.taskType === 'Dishes') && s.skipDate === checkDate).map(s => s.Name);
                let extraT = sList.filter(s => (s.taskType === 'All' || s.taskType === 'Table') && s.skipDate === checkDate).map(s => s.Name);
                let skipDishesLoop = true;
                while (skipDishesLoop && dList.length > 0) {
                    let sMatch = sList.findIndex(s => s.Name === dList[0] && (s.taskType === 'All' || s.taskType === 'Dishes') && checkDate >= s.skipDate);
                    if (sMatch !== -1) { sList.splice(sMatch, 1); dList.push(dList.shift()); } else { skipDishesLoop = false; }
                }
                let skipTableLoop = true;
                while (skipTableLoop && tList.length > 0) {
                    let sMatch = sList.findIndex(s => s.Name === tList[0] && (s.taskType === 'All' || s.taskType === 'Table') && checkDate >= s.skipDate);
                    if (sMatch !== -1) { sList.splice(sMatch, 1); tList.push(tList.shift()); } else { skipTableLoop = false; }
                }
                if (state.mList) {
                    let md = state.mList.find(m => m.mDate === checkDate && (m.taskType === 'All' || m.taskType === 'Dishes'));
                    if (md) { let idx = dList.indexOf(md.Name); if (idx > -1) { dList.splice(idx, 1); dList.unshift(md.Name); } }
                    let mt = state.mList.find(m => m.mDate === checkDate && (m.taskType === 'All' || m.taskType === 'Table'));
                    if (mt) { let idx = tList.indexOf(mt.Name); if (idx > -1) { tList.splice(idx, 1); tList.unshift(mt.Name); } }
                }
                let isdtoff = 1;
                let isttoff = 1;
                let customDText = '';
                let customTText = '';
                // console.log('offlan: ' + tofflen);
                for (let k = 0; k < tofflen; k++) {
                    let x = clone(toffList);
                    // console.log('xk: ' + x[k]);
                    if (checkDate == x[k].date && (x[k].task == 'All' || x[k].task == 'Dishes')) {
                        isdtoff = 0;
                        if (x[k].customText) {
                            customDText = x[k].customText;
                        }
                    };
                    if (checkDate == x[k].date && (x[k].task == 'All' || x[k].task == 'Table')) {
                        isttoff = 0;
                        if (x[k].customText) {
                            customTText = x[k].customText;
                        }
                    };
                };
                if (isdtoff == 1) { worker[0] = extraD.length ? `${dList[0]} & ${extraD[0]}` : dList[0]; dList.push(dList.shift()) } else { worker[0] = customDText || "No shift" };
                if (isttoff == 1) { worker[1] = extraT.length ? `${tList[0]} & ${extraT[0]}` : tList[0]; tList.push(tList.shift()) } else { worker[1] = customTText || "No shift" };
                dList.unshift(...dvac);
                tList.unshift(...tvac);
            };
        };
        return worker

    } else if (tswDate in history) { return [history[tswDate][0], history[tswDate][1]] }
};


function renderAll() {
    lastMonth = {};
    dPersons = [];
    tPersons = [];
    for (key in state.dListUp) {
        dPersons.push(state.dListUp[key]);
    };

    for (key in state.tListUp) {
        tPersons.push(state.tListUp[key]);
    };

    savedDate = new Date(state.savedDate);
    tsSavedDate = state.savedDate;
    startDate = new Date(state.startDate)
    state.history ? history = clone(state.history) : history = [];
    vacation = clone(state.vacation)

    toffList = [];
    for (key in state.toffList) {
        if (state.toffList[key] != null) toffList.push(state.toffList[key]);
    };
    if (typeof toffList != 'undefined') {
        tofflen = toffList.length;
    } else { toffList = []; tofflen = 0; };

    // console.log('tofflist: ' + JSON.stringify(toffList));
    //CALCULATE VACLIST
    vacList = [];
    for (key in state.vacation) {
        if (state.vacation[key] != null) vacList.push(state.vacation[key]);
    }
    if (typeof vacList != 'undefined') {
        vaclen = vacList.length;
    } else { vacList = []; vaclen = 0; };

    skipList = [];
    for (key in state.skipList) { 
        if (state.skipList[key] != null) skipList.push(state.skipList[key]); 
    }
    if (typeof skipList != 'undefined') { skiplen = skipList.length; } else { skipList = []; skiplen = 0; };

    // console.log(vacList);


    //history
    let past = 0;
    let maxh = Math.max(tPersons.length, 8);
    for (let i = 1; i < maxh; i++) {
        if (shiftType(new Date().getTime() - past * msDay) > 3) {
            i--;
        };
        past++;
    };
    // console.log(dPersons);
    // console.log('Past days:', past);

    //timestamp history
    let dayPast = new Date().getDate() - past;
    let monthPast = new Date().getMonth();
    let yearPast = new Date().getFullYear();
    while (dayPast < 1) {
        monthPast--;
        if (monthPast < 0) {
            monthPast = 11;
            yearPast--;
        };
        dayPast += daysInMonth(monthPast, yearPast);
    };
    datePast = new Date(yearPast, monthPast, dayPast);
    tsPast = datePast.getTime();
    syncWidget();
};

function syncWidget() {
    if (!window.AndroidNative || !window.AndroidNative.updateWidgetData) return;
    let widgetData = {};
    let todayTS = new Date().setHours(0, 0, 0, 0);
    for (let i = -7; i <= 21; i++) {
        let ts = todayTS + (i * msDay);
        let dObj = new Date(ts);
        let ymd = dObj.getFullYear() + "-" + String(dObj.getMonth() + 1).padStart(2, '0') + "-" + String(dObj.getDate()).padStart(2, '0');
        let sRes = shiftType(ts);
        let sCode = null;
        if (sRes === 0) sCode = "M1";
        else if (sRes === 1) sCode = "M2";
        else if (sRes === 2) sCode = "N1";
        else if (sRes === 3) sCode = "N2";
        if (sRes < 4) {
            let p = whoWork(ts);
            if (p) { widgetData[ymd] = { code: sCode, p1: p[0] || "", p2: p[1] || "" }; }
        }
    }
    window.AndroidNative.updateWidgetData(JSON.stringify(widgetData));
}

//disable right click
document.addEventListener('contextmenu', event => event.preventDefault());

let su = -2;
let sd = 2;
//scroll to current month
function scrollToday() {
    schedule.innerHTML = '';
    for (let i = su; i <= sd; i++) {
        renderCalendar(i);
    }
    let currentMonth = document.getElementById('current')
    currentMonth.scrollIntoView();
    schedule.scrollBy(0, -schedule.clientHeight / 2);
};


//scroll to change month
let pcalendar;
let ccalendar;
let ncalendar;
let pmonthname;
let cmonthname;
let nmonthname;
function scroll() {
    pcalendar = document.getElementById('calendar' + su);
    ccalendar = document.getElementById('calendar' + (su + 1));
    ncalendar = document.getElementById('calendar' + sd);
    pmonthname = document.getElementById('monthName' + su);
    cmonthname = document.getElementById('monthName' + (su + 1));
    nmonthname = document.getElementById('monthName' + sd);
    if (schedule.scrollTop < pcalendar.scrollHeight
    ) {
        // Scrolling up
        ncalendar.remove();
        nmonthname.remove();
        renderCalendar(su - 1);
        pmonthname.scrollIntoView();
        su--;
        sd--;
    } else if (schedule.scrollTop > pcalendar.scrollHeight * 3) {
        // Scrolling down
        pmonthname.remove();
        pcalendar.remove();
        renderCalendar(sd + 1);
        su++;
        sd++;
    }
};

// console.log(state);

function fetch2() {
    schedule.onscroll = function () { scroll() };
    Panel = '';
    
    try {
        if (window.AndroidAdmin && window.AndroidAdmin.isSessionValid()) {
            editLocked = false;
        }
    } catch(e) {}

    try {
        let workCached = loadWorkCache();
        if (workCached) {
            workState = JSON.parse(workCached);
            if (!workState || !workState.days) workState = { days: {} };
        }
    } catch (e) {}

    try {
        let cached = loadCache();
        if (cached) {
            state = clone(JSON.parse(cached));
            if (show == 'cal') { renderAll(); scrollToday(); weekdays.style.display = ''; schedule.onscroll = function () { scroll() }; }
            else if (show == 'work') { renderAll(); scrollWorkToday(); weekdays.style.display = ''; schedule.onscroll = function () { scrollWork() }; }
            else if (show == 'menu') { schedule.onscroll = undefined; weekdays.style.display = 'none'; schedule.innerHTML = ''; menuPanel(); }
            else if (show == 'corr') { schedule.onscroll = undefined; renderAll(); schedule.innerHTML = ''; correctionPanel(); weekdays.style.display = 'none'; }
            else if (show == 'edi') { schedule.onscroll = undefined; renderAll(); schedule.innerHTML = ''; editLocked ? editPasswordScreen() : editPanel(); weekdays.style.display = 'none'; }
            else if (show == 'eml') { schedule.onscroll = undefined; renderAll(); schedule.innerHTML = ''; mailsPanel(); weekdays.style.display = 'none'; }
            updateNavDropdown();
        }
    } catch (e) { console.error('PARSE ERROR: ' + e.message); }

    let ref = database.ref('/');
    ref.once('value', (snapshot) => {
        var data = snapshot.val();
        if (!data) return;
        if (data.workState) {
            workState = clone(data.workState);
            if (!workState.days) workState.days = {};
            saveWorkCache(JSON.stringify(workState));
        }
        if (!data.state) return;
        state = clone(data.state);
        saveCache(JSON.stringify(state));

        if (show == 'cal') {
            renderAll();
            scrollToday();
            weekdays.style.display = '';
            schedule.onscroll = function () { scroll() };
        } else if (show == 'work') {
            renderAll();
            scrollWorkToday();
            weekdays.style.display = '';
            schedule.onscroll = function () { scrollWork() };
        } else if (show == 'menu') {
            schedule.onscroll = undefined;
            weekdays.style.display = 'none';
            schedule.innerHTML = '';
            menuPanel();
        } else if (show == 'corr') {
            schedule.onscroll = undefined;
            renderAll();
            schedule.innerHTML = '';
            correctionPanel();
            weekdays.style.display = 'none';
        } else if (show == 'edi') {
            schedule.onscroll = undefined;
            renderAll();
            schedule.innerHTML = '';
            editLocked ? editPasswordScreen() : editPanel();
            weekdays.style.display = 'none';
        } else if (show == 'eml') {
            schedule.onscroll = undefined;
            renderAll();
            mailsPanel(true);
            weekdays.style.display = 'none';
        }
        updateNavDropdown();
        sendData();
    }).catch(error => {
        nativeToast('Database Locked: ' + error.message);
    });
};

try {
    database.ref('workState/').on('value', function (snap) {
        var val = snap.val();
        if (val) {
            workState = clone(val);
            if (!workState.days) workState.days = {};
            saveWorkCache(JSON.stringify(workState));
            if (show === 'work') {
                scrollWorkToday();
            }
        }
    });
} catch (e) {}

function goToday() {
    if (show === 'edi' && editDirty) {
        if (!confirm('You have unsaved changes. Discard and return to calendar?')) {
            return;
        }
        editDirty = false;
        editState = null;
    }
    if (show === 'work') {
        wsu = -2;
        wsd = 2;
        weekdays.style.display = '';
        scrollWorkToday();
        schedule.onscroll = function () { scrollWork(); };
        updateNavDropdown();
        return;
    }
    su = -2;
    sd = 2;
    show = 'cal';
    weekdays.style.display = '';
    scrollToday();
    schedule.onscroll = function () { scroll(); };
    updateNavDropdown();
}

function goCleanCalendar() {
    if (show === 'edi' && editDirty) {
        if (!confirm('You have unsaved changes. Discard and return to cleaning calendar?')) {
            return;
        }
        editDirty = false;
        editState = null;
    }
    show = 'cal';
    su = -2;
    sd = 2;
    weekdays.style.display = '';
    scrollToday();
    schedule.onscroll = function () { scroll(); };
    updateNavDropdown();
}

function goEditPanel() {
    if (show === 'edi') {
        if (!editLocked) {
            renderEditPanelContent();
        }
        updateNavDropdown();
        return;
    }
    show = 'edi';
    editDirty = false;
    initEditState(true);
    fetch2();
    updateNavDropdown();
}

function goMails() {
    if (show === 'edi' && editDirty) {
        if (!confirm('You have unsaved changes. Discard and view emails?')) {
            return;
        }
        editDirty = false;
        editState = null;
    }
    show = 'eml';
    fetch2();
    updateNavDropdown();
}

function goMenu() {
    if (show === 'edi' && editDirty) {
        if (!confirm('You have unsaved changes. Discard and open menu?')) {
            return;
        }
        editDirty = false;
        editState = null;
    }
    show = 'menu';
    schedule.onscroll = undefined;
    weekdays.style.display = 'none';
    schedule.innerHTML = '';
    menuPanel();
    updateNavDropdown();
}

function goWorkCalendar() {
    if (show === 'edi' && editDirty) {
        if (!confirm('You have unsaved changes. Discard and open work calendar?')) {
            return;
        }
        editDirty = false;
        editState = null;
    }
    show = 'work';
    wsu = -2;
    wsd = 2;
    weekdays.style.display = '';
    scrollWorkToday();
    schedule.onscroll = function () { scrollWork(); };
    updateNavDropdown();
}

function goCorrection() {
    if (show === 'edi' && editDirty) {
        if (!confirm('You have unsaved changes. Discard and open Correction?')) {
            return;
        }
        editDirty = false;
        editState = null;
    }
    show = 'corr';
    schedule.onscroll = undefined;
    weekdays.style.display = 'none';
    schedule.innerHTML = '';
    correctionPanel();
    updateNavDropdown();
}

var corrInputsD114 = {
    niveau: '4.23',
    densite: '1.285',
    fa: '59.40',
    uree: '19.56'
};

try {
    var savedCorr = localStorage.getItem('clean_corr_d114_state');
    if (savedCorr) {
        var parsedCorr = JSON.parse(savedCorr);
        if (parsedCorr && typeof parsedCorr === 'object') {
            if (parsedCorr.niveau !== undefined && parsedCorr.niveau !== '') corrInputsD114.niveau = parsedCorr.niveau;
            if (parsedCorr.densite !== undefined && parsedCorr.densite !== '') corrInputsD114.densite = parsedCorr.densite;
            if (parsedCorr.fa !== undefined && parsedCorr.fa !== '') corrInputsD114.fa = parsedCorr.fa;
            if (parsedCorr.uree !== undefined && parsedCorr.uree !== '') corrInputsD114.uree = parsedCorr.uree;
        }
    }
} catch (e) {}

function saveCorrD114State() {
    try {
        localStorage.setItem('clean_corr_d114_state', JSON.stringify(corrInputsD114));
    } catch (e) {}
}

function parseCorrNum(val) {
    if (val === null || val === undefined) return NaN;
    var s = String(val).trim().replace(',', '.');
    if (s === '') return NaN;
    var n = parseFloat(s);
    return isNaN(n) ? NaN : n;
}

function computeCorrectionD114(niveau, densite, fa, uree) {
    var b18 = parseCorrNum(niveau);
    var b19 = parseCorrNum(densite);
    var b20 = parseCorrNum(fa);
    var b21 = parseCorrNum(uree);

    if (isNaN(b18) || isNaN(b19) || isNaN(b20) || isNaN(b21)) {
        return null;
    }
    if (b18 <= 0 || b19 <= 0 || b20 <= 0 || b21 <= 0) {
        return null;
    }

    // Exact formulas from Tank D114 (Nouvelle correction model)
    var kTank = 16.5; // D114 constant
    var d20 = 57.0;   // Target FA %
    var d21 = 22.0;   // Target UREE %
    var d22 = 21.0;   // Target EAU %

    // Water % in tank
    var b22 = 100.0 - b20 - b21;

    // Initial total mass
    var c18 = b18 * kTank * b19;

    // Component masses in tank
    var c20 = (c18 * b20) / 100.0; // FA
    var c21 = (c18 * b21) / 100.0; // Urea
    var c22 = (c18 * b22) / 100.0; // Water

    // Target total mass (based on fixed FA)
    var e20 = (c20 * 100.0) / d20;
    // Target component masses
    var e21 = (e20 * d21) / 100.0;
    var e22 = (e20 * d22) / 100.0;

    // Quantity needed at 100%
    var f21 = e21 - c21;
    var f22 = e22 - c22;

    // Quantity at 55% solution
    var g21 = (f21 * 100.0) / 55.0;
    var g22 = f22;

    // Quantity to add
    var h21 = g21;
    var h22 = g22 - (g21 - f21);

    // Urea meters
    var i21 = h21 / 18.85; // in D205
    var ureaD202 = (i21 * 18.85) / 45.0; // in D202A/B

    // Water meters
    var i22 = h22 / 16.5;

    return {
        b18: b18, b19: b19, b20: b20, b21: b21, b22: b22,
        c18: c18,
        h21: h21, h22: h22,
        i21: i21, ureaD202: ureaD202,
        i22: i22
    };
}

function correctionPanel() {
    schedule.innerHTML = '';
    var container = document.createElement('div');
    container.className = 'correctionContainer';

    var header = document.createElement('div');
    header.className = 'correctionHeader';
    header.innerHTML = '<h2 class="correctionTitle"><span>🧪</span><span>تصحيح خزان D114</span></h2>' +
        '<p class="correctionSubtitle">حساب أمتار اليوريا والماء للإضافة</p>';
    container.appendChild(header);

    var grid = document.createElement('div');
    grid.className = 'corrGrid';
    grid.innerHTML = '' +
        '<div class="corrInputGroup">' +
        '  <label class="corrLabel"><span>مستوى الخزان (Niveau)</span></label>' +
        '  <div class="corrInputWrapper">' +
        '    <input type="text" inputmode="decimal" id="corrNiveau" class="corrInput" value="' + (corrInputsD114.niveau || '') + '" oninput="onCorrInputChange()">' +
        '    <span class="corrUnit">m</span>' +
        '  </div>' +
        '</div>' +
        '<div class="corrInputGroup">' +
        '  <label class="corrLabel"><span>الكثافة (Densité)</span></label>' +
        '  <div class="corrInputWrapper">' +
        '    <input type="text" inputmode="decimal" id="corrDensite" class="corrInput" value="' + (corrInputsD114.densite || '') + '" oninput="onCorrInputChange()">' +
        '    <span class="corrUnit">kg/L</span>' +
        '  </div>' +
        '</div>' +
        '<div class="corrInputGroup">' +
        '  <label class="corrLabel"><span>الفورمالين (FA %)</span></label>' +
        '  <div class="corrInputWrapper">' +
        '    <input type="text" inputmode="decimal" id="corrFa" class="corrInput" value="' + (corrInputsD114.fa || '') + '" oninput="onCorrInputChange()">' +
        '    <span class="corrUnit">%</span>' +
        '  </div>' +
        '</div>' +
        '<div class="corrInputGroup">' +
        '  <label class="corrLabel"><span>اليوريا (Urée %)</span></label>' +
        '  <div class="corrInputWrapper">' +
        '    <input type="text" inputmode="decimal" id="corrUree" class="corrInput" value="' + (corrInputsD114.uree || '') + '" oninput="onCorrInputChange()">' +
        '    <span class="corrUnit">%</span>' +
        '  </div>' +
        '</div>';
    container.appendChild(grid);

    var waterStrip = document.createElement('div');
    waterStrip.className = 'corrWaterStrip';
    waterStrip.id = 'corrWaterStrip';
    container.appendChild(waterStrip);

    var resultsGrid = document.createElement('div');
    resultsGrid.className = 'corrResultsGrid';
    resultsGrid.id = 'corrResultsGrid';
    container.appendChild(resultsGrid);

    var actions = document.createElement('div');
    actions.className = 'corrActions';
    actions.innerHTML = '' +
        '<button type="button" class="corrActionBtn" onclick="resetCorrToExample()">🔄 مثال (4.23 / 1.285 / 59.4 / 19.56)</button>' +
        '<button type="button" class="corrActionBtn" onclick="clearCorrInputs()">🗑️ مسح الحقول</button>';
    container.appendChild(actions);

    schedule.appendChild(container);
    updateCorrView();
}

function onCorrInputChange() {
    var inNiveau = document.getElementById('corrNiveau');
    var inDensite = document.getElementById('corrDensite');
    var inFa = document.getElementById('corrFa');
    var inUree = document.getElementById('corrUree');

    if (inNiveau) corrInputsD114.niveau = inNiveau.value;
    if (inDensite) corrInputsD114.densite = inDensite.value;
    if (inFa) corrInputsD114.fa = inFa.value;
    if (inUree) corrInputsD114.uree = inUree.value;

    saveCorrD114State();
    updateCorrView();
}

function resetCorrToExample() {
    corrInputsD114 = {
        niveau: '4.23',
        densite: '1.285',
        fa: '59.40',
        uree: '19.56'
    };
    saveCorrD114State();
    correctionPanel();
}

function clearCorrInputs() {
    corrInputsD114 = {
        niveau: '',
        densite: '',
        fa: '',
        uree: ''
    };
    saveCorrD114State();
    correctionPanel();
}

function updateCorrView() {
    var strip = document.getElementById('corrWaterStrip');
    var resultsGrid = document.getElementById('corrResultsGrid');
    if (!strip || !resultsGrid) return;

    var f = parseCorrNum(corrInputsD114.fa);
    var u = parseCorrNum(corrInputsD114.uree);

    var calcWater = (!isNaN(f) && !isNaN(u)) ? (100.0 - f - u).toFixed(2) : '--';
    strip.innerHTML = '<span>💧 نسبة الماء المحسوبة:</span><span class="corrWaterValue">' + calcWater + '%</span>';

    var res = computeCorrectionD114(
        corrInputsD114.niveau,
        corrInputsD114.densite,
        corrInputsD114.fa,
        corrInputsD114.uree
    );

    if (!res) {
        resultsGrid.innerHTML = '' +
            '<div class="corrResultCard urea" style="grid-column: span 2; padding: 4vmin;">' +
            '  <div style="font-size: 3vmin; color: var(--text-muted);">' +
            '    ⚠️ يرجى إدخال قيم صالحة للمستوى، الكثافة، FA، واليوريا لعرض النتائج' +
            '  </div>' +
            '</div>';
        return;
    }

    var ureaSign = res.i21 >= 0 ? '+' : '';
    var ureaMStr = ureaSign + res.i21.toFixed(3) + ' m';
    var ureaCmStr = ureaSign + (res.i21 * 100).toFixed(1) + ' cm';
    var ureaClass = res.i21 > 0 ? 'positive' : (res.i21 < 0 ? 'negative' : 'zero');

    var urea202Sign = res.ureaD202 >= 0 ? '+' : '';
    var urea202MStr = urea202Sign + res.ureaD202.toFixed(3) + ' m';
    var urea202CmStr = urea202Sign + (res.ureaD202 * 100).toFixed(1) + ' cm';

    var waterSign = res.i22 >= 0 ? '+' : '';
    var waterMStr = waterSign + res.i22.toFixed(3) + ' m';
    var waterCmStr = waterSign + (res.i22 * 100).toFixed(1) + ' cm';
    var waterClass = res.i22 > 0 ? 'positive' : (res.i22 < 0 ? 'negative' : 'zero');

    resultsGrid.innerHTML = '' +
        '<div class="corrResultCard urea">' +
        '  <div class="corrResultHeader"><span>🧪</span><span>اليوريا (Urée)</span></div>' +
        '  <div class="corrResultMain ' + ureaClass + '">' + ureaMStr + '</div>' +
        '  <div class="corrResultUnit">' + ureaCmStr + ' (خزان D205)</div>' +
        '  <div class="corrResultSecondary">' +
        '    <span>أو في خزان D202A/B:</span>' +
        '    <b style="color:#38bdf8; font-size:3vmin;">' + urea202MStr + ' (' + urea202CmStr + ')</b>' +
        '  </div>' +
        '  <div class="corrResultSub">' +
        '    <div>الكمية للإضافة: <b style="color:#e2e8f0;">' + (res.h21 >= 0 ? '+' : '') + res.h21.toFixed(2) + ' طن (55%)</b></div>' +
        '  </div>' +
        '</div>' +
        '<div class="corrResultCard water">' +
        '  <div class="corrResultHeader"><span>💧</span><span>الماء (Eau)</span></div>' +
        '  <div class="corrResultMain ' + waterClass + '">' + waterMStr + '</div>' +
        '  <div class="corrResultUnit">' + waterCmStr + '</div>' +
        '  <div class="corrResultSub" style="margin-top:auto;">' +
        '    <div>الكمية للإضافة: <b style="color:#e2e8f0;">' + (res.h22 >= 0 ? '+' : '') + res.h22.toFixed(2) + ' طن</b></div>' +
        '  </div>' +
        '</div>';
}

function toggleNavDropdown(event) {
    if (event) {
        event.stopPropagation();
    }
    var dd = document.getElementById('navDropdown');
    if (dd) {
        dd.classList.toggle('open');
    }
}

function closeNavDropdown() {
    var dd = document.getElementById('navDropdown');
    if (dd) {
        dd.classList.remove('open');
    }
}

function navSelect(action) {
    closeNavDropdown();
    if (action === 'cal') {
        goCleanCalendar();
    } else if (action === 'work') {
        goWorkCalendar();
    } else if (action === 'today') {
        goToday();
    } else if (action === 'corr') {
        goCorrection();
    } else if (action === 'edi') {
        goEditPanel();
    } else if (action === 'menu') {
        goMenu();
    }
}

document.addEventListener('click', function (e) {
    var dd = document.getElementById('navDropdown');
    if (dd && dd.classList.contains('open') && !dd.contains(e.target)) {
        closeNavDropdown();
    }
});

function updateNavDropdown() {
    var label = document.getElementById('navDropdownLabel');
    var itemClean = document.getElementById('itemClean');
    var itemWork = document.getElementById('itemWork');
    var itemToday = document.getElementById('itemToday');
    var itemCorrection = document.getElementById('itemCorrection');
    var itemSettings = document.getElementById('itemSettings');

    if (itemClean) itemClean.classList.remove('activeNavItem');
    if (itemWork) itemWork.classList.remove('activeNavItem');
    if (itemToday) itemToday.classList.remove('activeNavItem');
    if (itemCorrection) itemCorrection.classList.remove('activeNavItem');
    if (itemSettings) itemSettings.classList.remove('activeNavItem');

    if (show === 'cal') {
        if (label) label.textContent = 'جدول النظافة';
        if (itemClean) itemClean.classList.add('activeNavItem');
    } else if (show === 'work') {
        if (label) label.textContent = 'جدول العمل';
        if (itemWork) itemWork.classList.add('activeNavItem');
    } else if (show === 'corr') {
        if (label) label.textContent = 'Correction';
        if (itemCorrection) itemCorrection.classList.add('activeNavItem');
    } else if (show === 'edi') {
        if (label) label.textContent = 'اعدادات';
        if (itemSettings) itemSettings.classList.add('activeNavItem');
    } else if (show === 'menu') {
        if (label) label.textContent = 'القائمة';
    } else if (show === 'eml') {
        if (label) label.textContent = 'البريد';
    }
}

function updateNavButtons() {
    updateNavDropdown();
}

function menuPanel() {
    schedule.innerHTML = '';
    var container = document.createElement('div');
    container.className = 'menuContainer';

    var title = document.createElement('div');
    title.style.textAlign = 'center';
    title.style.fontSize = '4.5vmin';
    title.style.fontWeight = 'bold';
    title.style.color = '#38bdf8';
    title.style.marginBottom = '2vmin';
    title.textContent = '📋 القائمة الرئيسية';
    container.appendChild(title);

    var btnWork = document.createElement('button');
    btnWork.className = 'menuBtn';
    btnWork.innerHTML = '💼 جدول العمل<br><span style="font-size:2.8vmin;opacity:0.75;font-weight:normal;">Work Calendar</span>';
    btnWork.onclick = function () { goWorkCalendar(); };
    container.appendChild(btnWork);

    var btnClean = document.createElement('button');
    btnClean.className = 'menuBtn';
    btnClean.innerHTML = '🧹 جدول النظافة<br><span style="font-size:2.8vmin;opacity:0.75;font-weight:normal;">Cleaning Calendar</span>';
    btnClean.onclick = function () {
        goCleanCalendar();
    };
    container.appendChild(btnClean);

    var btnCorr = document.createElement('button');
    btnCorr.className = 'menuBtn';
    btnCorr.innerHTML = '✏️ التصحيح<br><span style="font-size:2.8vmin;opacity:0.75;font-weight:normal;">Correction</span>';
    btnCorr.onclick = function () {
        goCorrection();
    };
    container.appendChild(btnCorr);

    var btnEdit = document.createElement('button');
    btnEdit.className = 'menuBtn';
    btnEdit.innerHTML = '⚙️ الإعدادات<br><span style="font-size:2.8vmin;opacity:0.75;font-weight:normal;">Settings</span>';
    btnEdit.onclick = function () { goEditPanel(); };
    container.appendChild(btnEdit);

    var btnMail = document.createElement('button');
    btnMail.className = 'menuBtn';
    btnMail.innerHTML = '📨 البريد والرسائل<br><span style="font-size:2.8vmin;opacity:0.75;font-weight:normal;">Emails</span>';
    btnMail.onclick = function () { goMails(); };
    container.appendChild(btnMail);

    var btnUpdate = document.createElement('button');
    btnUpdate.className = 'menuBtn';
    var webVer = 0;
    try {
        if (window.AndroidNative && window.AndroidNative.getInstalledWebVersion) {
            webVer = window.AndroidNative.getInstalledWebVersion();
        }
    } catch(e) {}
    var verSub = webVer > 0 ? 'Web v' + webVer : 'Check for Updates';
    btnUpdate.innerHTML = '🔄 تحديث التطبيق<br><span style="font-size:2.8vmin;opacity:0.75;font-weight:normal;">' + verSub + '</span>';
    btnUpdate.onclick = function () {
        if (window.AndroidNative && window.AndroidNative.checkForUpdatesManually) {
            window.AndroidNative.checkForUpdatesManually();
        } else {
            nativeToast('التحديثات التلقائية متوفرة عبر تطبيق الأندرويد.');
        }
    };
    container.appendChild(btnUpdate);

    schedule.appendChild(container);
}

var wsu = -2;
var wsd = 2;

function scrollWorkToday() {
    schedule.innerHTML = '';
    for (var i = wsu; i <= wsd; i++) {
        renderWorkCalendar(i);
    }
    var currentMonth = document.getElementById('workCurrent');
    if (currentMonth) {
        currentMonth.scrollIntoView();
        schedule.scrollBy(0, -schedule.clientHeight / 2);
    } else {
        var midMonth = document.getElementById('workMonthName0');
        if (midMonth) {
            midMonth.scrollIntoView();
        }
    }
}

function scrollWork() {
    var pcalendar = document.getElementById('workCalendar' + wsu);
    var ncalendar = document.getElementById('workCalendar' + wsd);
    var pmonthname = document.getElementById('workMonthName' + wsu);
    var nmonthname = document.getElementById('workMonthName' + wsd);
    if (!pcalendar || !ncalendar) return;

    if (schedule.scrollTop < pcalendar.scrollHeight) {
        ncalendar.remove();
        nmonthname.remove();
        renderWorkCalendar(wsu - 1);
        pmonthname.scrollIntoView();
        wsu--;
        wsd--;
    } else if (schedule.scrollTop > pcalendar.scrollHeight * 3) {
        pmonthname.remove();
        pcalendar.remove();
        renderWorkCalendar(wsd + 1);
        wsu++;
        wsd++;
    }
}

function renderWorkCalendar(i) {
    var month = new Date().getMonth() + i;
    var year = new Date().getFullYear();
    while (month > 11) {
        year++;
        month -= 12;
    }
    while (month < 0) {
        year--;
        month += 12;
    }

    var days = daysInMonth(month, year);
    var frag = document.createDocumentFragment();

    var monthName = document.createElement('div');
    monthName.id = 'workMonthName' + i;
    monthName.className = 'monthName';
    monthName.innerText = '💼 ' + new Date(year, month).toLocaleString('ar-DZ', { month: 'long', year: 'numeric' });
    frag.appendChild(monthName);

    var calendar = document.createElement('div');
    calendar.className = 'calendar';
    calendar.id = 'workCalendar' + i;
    frag.appendChild(calendar);

    monthName.style.order = i;
    calendar.style.order = i;
    calendar.style.zIndex = 1;
    monthName.style.zIndex = 50 + i;

    var emptyDays1 = new Date(year, month, 1).getDay();
    for (var j = 0; j < emptyDays1; j++) {
        var emptyDay1 = document.createElement('div');
        emptyDay1.className = 'day empty';
        calendar.appendChild(emptyDay1);
    }

    var cDate;
    for (var j = 1; j <= days; j++) {
        cDate = new Date(year, month, j);
        var mStr = (month + 1 < 10 ? '0' : '') + (month + 1);
        var dStr = (j < 10 ? '0' : '') + j;
        var ymd = year + '-' + mStr + '-' + dStr;

        var dayDiv = document.createElement('div');
        dayDiv.className = 'day workDay';
        dayDiv.id = 'workDay-' + ymd;
        dayDiv.setAttribute('data-ymd', ymd);
        dayDiv.innerHTML = '<b>' + j + '</b>';

        var p1 = '';
        var p2 = '';
        if (workState && workState.days && workState.days[ymd]) {
            var entry = workState.days[ymd];
            if (typeof entry === 'object') {
                if (Array.isArray(entry)) {
                    p1 = entry[0] || '';
                    p2 = entry[1] || '';
                } else {
                    p1 = entry.p1 || '';
                    p2 = entry.p2 || '';
                }
            } else if (typeof entry === 'string') {
                p1 = entry;
            }
        }

        if (p1 || p2) {
            dayDiv.classList.add('hasWork');
            if (p1) {
                var p1El = document.createElement('div');
                p1El.textContent = p1;
                p1El.title = p1;
                dayDiv.appendChild(p1El);
            }
            if (p2) {
                var p2El = document.createElement('div');
                p2El.textContent = p2;
                p2El.title = p2;
                dayDiv.appendChild(p2El);
            }
        }

        if (cDate.getDate() === today && cDate.getMonth() === new Date().getMonth() && cDate.getFullYear() === new Date().getFullYear()) {
            dayDiv.classList.add('current', 'workCurrent');
            dayDiv.id = 'workCurrent';
        }

        (function (dateKey, dayNumber, monthYearStr) {
            dayDiv.onclick = function () {
                openWorkDayModal(dateKey, dayNumber, monthYearStr);
            };
        })(ymd, j, new Date(year, month).toLocaleString('ar-DZ', { month: 'long', year: 'numeric' }));

        calendar.appendChild(dayDiv);
    }

    var emptyDays2 = new Date(year, month, days).getDay();
    for (var j = emptyDays2 + 1; j <= 6; j++) {
        var emptyDay2 = document.createElement('div');
        emptyDay2.className = 'day empty';
        calendar.appendChild(emptyDay2);
    }

    schedule.appendChild(frag);
}

function openWorkDayModal(ymd, dayNum, monthStr) {
    var oldModal = document.getElementById('workDayModalOverlay');
    if (oldModal) oldModal.remove();

    var initP1 = '';
    var initP2 = '';
    if (workState && workState.days && workState.days[ymd]) {
        var entry = workState.days[ymd];
        if (typeof entry === 'object') {
            if (Array.isArray(entry)) {
                initP1 = entry[0] || '';
                initP2 = entry[1] || '';
            } else {
                initP1 = entry.p1 || '';
                initP2 = entry.p2 || '';
            }
        } else if (typeof entry === 'string') {
            initP1 = entry;
        }
    }

    var allWorkers = [];
    if (state.dListUp && Array.isArray(state.dListUp)) {
        for (var i = 0; i < state.dListUp.length; i++) {
            if (state.dListUp[i] && allWorkers.indexOf(state.dListUp[i]) === -1) {
                allWorkers.push(state.dListUp[i]);
            }
        }
    }
    if (state.tListUp && Array.isArray(state.tListUp)) {
        for (var i = 0; i < state.tListUp.length; i++) {
            if (state.tListUp[i] && allWorkers.indexOf(state.tListUp[i]) === -1) {
                allWorkers.push(state.tListUp[i]);
            }
        }
    }

    var overlay = document.createElement('div');
    overlay.className = 'workModalOverlay';
    overlay.id = 'workDayModalOverlay';

    var modal = document.createElement('div');
    modal.className = 'workModalBox';

    var title = document.createElement('h3');
    title.textContent = '💼 جدول العمل (Work Calendar)';
    modal.appendChild(title);

    var dateHeader = document.createElement('div');
    dateHeader.className = 'workModalDate';
    dateHeader.innerHTML = 'اليوم ' + dayNum + ' - ' + monthStr + '<br><span style="font-size:2.8vmin;opacity:0.7;">' + ymd + '</span>';
    modal.appendChild(dateHeader);

    // Group 1
    var group1 = document.createElement('div');
    group1.className = 'workInputGroup';
    var label1 = document.createElement('label');
    label1.textContent = 'العامل الأول (Person 1):';
    group1.appendChild(label1);

    var row1 = document.createElement('div');
    row1.className = 'workInputRow';

    var input1 = document.createElement('input');
    input1.type = 'text';
    input1.placeholder = 'اسم العامل الأول...';
    input1.value = initP1 || '';
    row1.appendChild(input1);

    var select1 = document.createElement('select');
    var defaultOpt1 = document.createElement('option');
    defaultOpt1.value = '';
    defaultOpt1.textContent = 'اختر اسم...';
    select1.appendChild(defaultOpt1);
    for (var w = 0; w < allWorkers.length; w++) {
        var opt = document.createElement('option');
        opt.value = allWorkers[w];
        opt.textContent = allWorkers[w];
        select1.appendChild(opt);
    }
    select1.onchange = function () {
        if (select1.value) {
            input1.value = select1.value;
        }
    };
    row1.appendChild(select1);
    group1.appendChild(row1);
    modal.appendChild(group1);

    // Group 2
    var group2 = document.createElement('div');
    group2.className = 'workInputGroup';
    var label2 = document.createElement('label');
    label2.textContent = 'العامل الثاني (Person 2):';
    group2.appendChild(label2);

    var row2 = document.createElement('div');
    row2.className = 'workInputRow';

    var input2 = document.createElement('input');
    input2.type = 'text';
    input2.placeholder = 'اسم العامل الثاني...';
    input2.value = initP2 || '';
    row2.appendChild(input2);

    var select2 = document.createElement('select');
    var defaultOpt2 = document.createElement('option');
    defaultOpt2.value = '';
    defaultOpt2.textContent = 'اختر اسم...';
    select2.appendChild(defaultOpt2);
    for (var w = 0; w < allWorkers.length; w++) {
        var opt2 = document.createElement('option');
        opt2.value = allWorkers[w];
        opt2.textContent = allWorkers[w];
        select2.appendChild(opt2);
    }
    select2.onchange = function () {
        if (select2.value) {
            input2.value = select2.value;
        }
    };
    row2.appendChild(select2);
    group2.appendChild(row2);
    modal.appendChild(group2);

    // Action buttons
    var actions = document.createElement('div');
    actions.className = 'workModalActions';

    var saveBtn = document.createElement('button');
    saveBtn.className = 'toffButton';
    saveBtn.style.background = '#0284c7';
    saveBtn.style.color = '#ffffff';
    saveBtn.style.padding = '1.5vmin 3vmin';
    saveBtn.style.borderRadius = '1vmin';
    saveBtn.style.fontSize = '3vmin';
    saveBtn.style.fontWeight = 'bold';
    saveBtn.style.border = 'none';
    saveBtn.style.cursor = 'pointer';
    saveBtn.textContent = '💾 حفظ (Save)';
    saveBtn.onclick = function () {
        var val1 = input1.value ? input1.value.trim() : '';
        var val2 = input2.value ? input2.value.trim() : '';
        if (!workState) workState = { days: {} };
        if (!workState.days) workState.days = {};

        if (val1 || val2) {
            workState.days[ymd] = { p1: val1, p2: val2 };
        } else {
            delete workState.days[ymd];
        }
        saveWorkState();
        overlay.remove();

        var cell = document.querySelector('[data-ymd="' + ymd + '"]') || document.getElementById('workDay-' + ymd);
        if (cell) {
            cell.innerHTML = '<b>' + dayNum + '</b>';
            if (val1 || val2) {
                cell.classList.add('hasWork');
                if (val1) {
                    var p1Div = document.createElement('div');
                    p1Div.textContent = val1;
                    p1Div.title = val1;
                    cell.appendChild(p1Div);
                }
                if (val2) {
                    var p2Div = document.createElement('div');
                    p2Div.textContent = val2;
                    p2Div.title = val2;
                    cell.appendChild(p2Div);
                }
            } else {
                cell.classList.remove('hasWork');
            }
            cell.onclick = function () {
                openWorkDayModal(ymd, dayNum, monthStr);
            };
        }
        nativeToast('تم حفظ جدول العمل بنجاح (Saved)');
    };
    actions.appendChild(saveBtn);

    var clearBtn = document.createElement('button');
    clearBtn.className = 'toffButton';
    clearBtn.style.background = '#e11d48';
    clearBtn.style.color = '#ffffff';
    clearBtn.style.padding = '1.5vmin 3vmin';
    clearBtn.style.borderRadius = '1vmin';
    clearBtn.style.fontSize = '3vmin';
    clearBtn.style.fontWeight = 'bold';
    clearBtn.style.border = 'none';
    clearBtn.style.cursor = 'pointer';
    clearBtn.textContent = '🗑️ مسح (Clear)';
    clearBtn.onclick = function () {
        if (confirm('هل أنت متأكد من مسح الأسماء لهذا اليوم؟\n(Clear names for this day?)')) {
            if (workState && workState.days) {
                delete workState.days[ymd];
            }
            saveWorkState();
            overlay.remove();

            var cell = document.querySelector('[data-ymd="' + ymd + '"]') || document.getElementById('workDay-' + ymd);
            if (cell) {
                cell.innerHTML = '<b>' + dayNum + '</b>';
                cell.classList.remove('hasWork');
                cell.onclick = function () {
                    openWorkDayModal(ymd, dayNum, monthStr);
                };
            }
            nativeToast('تم مسح بيانات اليوم (Cleared)');
        }
    };
    actions.appendChild(clearBtn);

    var cancelBtn = document.createElement('button');
    cancelBtn.className = 'toffButton';
    cancelBtn.style.background = 'transparent';
    cancelBtn.style.color = 'var(--text-main)';
    cancelBtn.style.padding = '1.5vmin 3vmin';
    cancelBtn.style.borderRadius = '1vmin';
    cancelBtn.style.fontSize = '3vmin';
    cancelBtn.style.fontWeight = 'bold';
    cancelBtn.style.border = '1px solid var(--glass-border)';
    cancelBtn.style.cursor = 'pointer';
    cancelBtn.textContent = 'إلغاء (Cancel)';
    cancelBtn.onclick = function () {
        overlay.remove();
    };
    actions.appendChild(cancelBtn);

    modal.appendChild(actions);
    overlay.appendChild(modal);

    overlay.onclick = function (e) {
        if (e.target === overlay) {
            overlay.remove();
        }
    };

    document.body.appendChild(overlay);
}

let currentMailIndex = 0;

function renderMailView() {
    if (!state.mailsHistory || state.mailsHistory.length === 0) {
         schedule.innerHTML = '<div style="text-align: center; margin-top: 10vmin; opacity: 0.7; font-size: 3.5vmin;">لا توجد رسائل مخزنة (No Emails Found)</div>';
         return;
    }
    
    let histObj = state.mailsHistory[currentMailIndex];
    let html = '<div class="mailHeader">';
    
    if (state.mailsHistory.length > 1) {
        html += '<select id="mailSelector" onchange="currentMailIndex=this.value; renderMailView();" style="font-size: 3.5vmin; padding: 1vmin; border-radius: 1vmin; background: var(--glass-bg); color: var(--text-main); border: 1px solid var(--glass-border); max-width: 80vw;">';
        state.mailsHistory.forEach((item, idx) => {
            let sel = (idx == currentMailIndex) ? 'selected' : '';
            let label = (item.subject ? item.subject + ' | ' : '') + item.dateStr;
            html += '<option value="' + idx + '" ' + sel + ' style="color: black;">' + label + '</option>';
        });
        html += '</select>';
    } else {
        let label = (histObj.subject ? histObj.subject + ' | ' : '') + histObj.dateStr;
        html += 'رسالة: ' + label;
    }
    html += '</div>';
    
    let tableData = histObj.table;
    html += '<div class="tableContainer"><table class="glassTable">';
    tableData.forEach((row, rIndex) => {
        html += '<tr>';
        row.forEach(cell => {
            let content = cell;
            if (typeof cell === 'string' && cell.indexOf('T') > -1 && cell.indexOf('Z') > -1) {
               content = new Date(cell).toLocaleDateString();
            }
            let tag = (rIndex === 0) ? 'th' : 'td';
            html += '<' + tag + '>' + content + '</' + tag + '>';
        });
        html += '</tr>';
    });
    html += '</table></div>';
    
    // Append detailed mail info underneath the table
    let subj = histObj.subject || 'بدون عنوان';
    let rDate = histObj.dateStr || 'تاريخ غير معروف';
    html += `<div style="margin: 4vmin auto 8vmin auto; width: 90%; max-width: 600px; text-align: center; background: var(--glass-bg); border: 1px solid var(--glass-border); border-radius: 2vmin; padding: 3.5vmin; box-shadow: var(--glass-shadow); backdrop-filter: var(--glass-blur); -webkit-backdrop-filter: var(--glass-blur); color: var(--text-main);">
                <div style="font-size: 4vmin; font-weight: bold; margin-bottom: 2vmin;">${subj}</div>
                <div style="font-size: 3.3vmin; opacity: 0.85;">
                    🗓️ تاريخ الاستلام: <b style="font-family: monospace; font-size: 3.6vmin;">${rDate}</b>
                </div>
             </div>`;
             
    try {
        if (window.AndroidAdmin && window.AndroidAdmin.isSessionValid()) {
            html += `<div style="text-align: center; margin-bottom: 5vmin;">
                        <button onclick="window.deleteCurrentMail()" style="background: #ff4d4d; color: white; border: none; padding: 2vmin 4vmin; border-radius: 1vmin; font-size: 3.5vmin; font-weight: bold; box-shadow: 0 4px 10px rgba(255,0,0,0.3);">🗑️ مسح الرسالة (Delete Mail)</button>
                     </div>`;
        }
    } catch(e) {}
             
    schedule.innerHTML = html;
}

window.deleteCurrentMail = function() {
    if (confirm('هل أنت متأكد من حذف هذه الرسالة؟\n(Are you sure you want to permanently delete this mail?)')) {
        state.mailsHistory.splice(currentMailIndex, 1);
        database.ref('state/mailsHistory').set(state.mailsHistory);
        saveCache(JSON.stringify(state));
        currentMailIndex = 0;
        mailsPanel(true);
    }
};

function mailsPanel(isBackgroundUpdate = false) {
    state.mailsHistory = state.mailsHistory || [];
    
    if (state.mailsHistory.length === 0 && !isBackgroundUpdate) {
        schedule.innerHTML = '<div style="text-align: center; margin-top: 10vmin; font-size: 4vmin;">جاري التحميل... ⏳</div>';
    }
    
    if (state.mailsHistory.length > 0) {
        if (!isBackgroundUpdate) currentMailIndex = 0;
        renderMailView();
    }
    
    if (isBackgroundUpdate) return;
    
    fetch('https://script.google.com/macros/s/AKfycbwgTlBZhxPFFUNFvuCNa5iPJxCuGtQxHQwbget17vhz2-Enc-5xbjXw50QLRxJkndJk/exec')
    .then(response => response.json())
    .then(data => {
        if(data.error) {
            if (state.mailsHistory.length === 0) {
                schedule.innerHTML = '<div style="text-align: center; margin-top: 10vmin; opacity: 0.7; font-size: 3.5vmin;">' + data.error + '</div>';
            }
            return;
        }
        
        let fetchedDateStr = data.date;
        let fetchedSubject = data.subject || "";
        let exists = state.mailsHistory.some(m => m.dateStr === fetchedDateStr);
        
        if (!exists) {
            let src = data.table;
            let targetTable = [];
            let isF36 = fetchedSubject.toUpperCase().includes('F36');
            
            if (isF36 && src && src.length >= 19) {
                 for (let i = 12; i <= 18; i++) {
                     let mappedRow = [];
                     for (let j = 0; j <= 5; j++) {
                         mappedRow.push(src[i][j] || "");
                     }
                     targetTable.push(mappedRow);
                 }
            } else if (src && src.length >= 22) {
                 for (let i = 11; i <= 21; i++) {
                     let mappedRow = [];
                     for (let j = 0; j <= 11; j++) {
                         mappedRow.push(src[i][j] || "");
                     }
                     targetTable.push(mappedRow);
                 }
            } else {
                 targetTable = src;
            }
            
            state.mailsHistory.unshift({
                dateStr: fetchedDateStr,
                subject: fetchedSubject,
                timestamp: new Date().getTime(),
                table: targetTable
            });
            
            let thirtyDaysMs = 30 * 24 * 60 * 60 * 1000;
            let now = new Date().getTime();
            state.mailsHistory = state.mailsHistory.filter(m => (now - m.timestamp) < thirtyDaysMs);
            
            database.ref('state/mailsHistory').set(state.mailsHistory);
            
            sendData();
            saveCache(JSON.stringify(state));
            
            currentMailIndex = 0;
            if (show === 'eml') renderMailView();
        }
    }).catch(err => {
        console.error(err);
        if (state.mailsHistory.length === 0) {
            schedule.innerHTML = '<div style="text-align: center; margin-top: 10vmin; opacity: 0.7; font-size: 3.5vmin;">خطأ في الاتصال بالبريد ❌</div>';
        }
    });
}
let editLocked = true;

function firebaseLoginScreen() {
    let passRow = document.createElement('div');
    passRow.className = 'passRow';
    schedule.appendChild(passRow);
    let passLabel = document.createElement('label');
    passLabel.textContent = 'Enter Access (Read) Password:';
    passLabel.className = 'passLabel';
    passRow.appendChild(passLabel);
    let passForm = document.createElement('form');
    passForm.id = 'passForm';
    passForm.onsubmit = function (event) {
        event.preventDefault();
        const adminEmail = 'admin@cleanshift.com';
        firebase.auth().signInWithEmailAndPassword(adminEmail, passInput.value)
            .then((userCredential) => {
                schedule.innerHTML = '';
                show = 'cal';
                locked = false;
                fetch2();
            })
            .catch((error) => {
                nativeToast('Authentication Failed: ' + error.message);
            });
    };
    passRow.appendChild(passForm);
    let passInput = document.createElement('input');
    passInput.id = 'passInput';
    passInput.type = 'password';
    passInput.style.background = 'white';
    passInput.style.color = 'black';
    passInput.required = true;
    passForm.appendChild(passInput);
    let passButton = document.createElement('button');
    passButton.textContent = 'Unlock App';
    passButton.type = 'submit';
    passButton.className = 'passButton';
    passForm.appendChild(passButton);
}

function editPasswordScreen() {
    let passRow = document.createElement('div');
    passRow.className = 'passRow';
    schedule.appendChild(passRow);
    let passLabel = document.createElement('label');
    passLabel.textContent = 'Enter Settings (Write) Password:';
    passLabel.className = 'passLabel';
    passRow.appendChild(passLabel);
    let passForm = document.createElement('form');
    passForm.id = 'passForm';
    passForm.onsubmit = function (event) {
        event.preventDefault();
        let valid = false;
        try {
            valid = window.AndroidAdmin.loginAdminPlaintext(passInput.value);
        } catch(e) { 
            nativeToast('Android Bridge Error');
            return;
        }
        if (valid) {
            schedule.innerHTML = '';
            editLocked = false;
            editPanel();
        } else {
            nativeToast('Incorrect Settings Password');
        }
    };
    passRow.appendChild(passForm);
    let passInput = document.createElement('input');
    passInput.id = 'passInput';
    passInput.type = 'password';
    passInput.style.background = 'white';
    passInput.style.color = 'black';
    passInput.required = true;
    passForm.appendChild(passInput);
    let submitBtn = document.createElement('button');
    submitBtn.type = 'submit';
    submitBtn.className = 'passButton';
    submitBtn.textContent = 'Unlock Settings';
    passForm.appendChild(submitBtn);
}

let editState = null;
let editDirty = false;

function cleanArray(item) {
    if (!item) return [];
    if (Array.isArray(item)) {
        return item.filter(function (x) { return x !== null && x !== undefined; });
    }
    var arr = [];
    for (var k in item) {
        if (item[k] !== null && item[k] !== undefined) arr.push(item[k]);
    }
    return arr;
}

function normalizeEditState() {
    if (!editState) editState = clone(state);
    editState.vacation = cleanArray(editState.vacation);
    editState.dListUp = cleanArray(editState.dListUp);
    editState.tListUp = cleanArray(editState.tListUp);
    editState.toffList = cleanArray(editState.toffList);
    editState.skipList = cleanArray(editState.skipList);
    editState.mList = cleanArray(editState.mList);
}

function initEditState(force) {
    if (!editState || force || !editDirty) {
        editState = clone(state);
        normalizeEditState();
        editDirty = false;
    }
}

function saveEditPanelChanges() {
    if (!editState) return;

    state = clone(editState);
    state.vacation = cleanArray(state.vacation);
    state.dListUp = cleanArray(state.dListUp);
    state.tListUp = cleanArray(state.tListUp);
    state.toffList = cleanArray(state.toffList);
    state.skipList = cleanArray(state.skipList);
    state.mList = cleanArray(state.mList);

    editDirty = false;
    editState = clone(state);

    database.ref('state/').set(state);
    saveCache(JSON.stringify(state));

    renderAll();
    syncWidget();
    sendData();

    nativeToast('Schedule changes saved successfully!');
    renderEditPanelContent();
}

function discardEditPanelChanges() {
    if (editDirty) {
        if (!confirm('Discard all unsaved edits and restore current active state?')) {
            return;
        }
    }
    editDirty = false;
    editState = clone(state);
    normalizeEditState();
    nativeToast('Changes discarded.');
    renderEditPanelContent();
}

function createEditActionsBar(isBottom) {
    var bar = document.createElement('div');
    bar.className = isBottom ? 'editActionsBar bottom' : 'editActionsBar';

    var saveBtn = document.createElement('button');
    saveBtn.className = 'saveButton' + (editDirty ? ' dirty' : '');
    saveBtn.textContent = editDirty ? '💾 Save Changes *' : '💾 Save Changes';
    saveBtn.onclick = function () {
        saveEditPanelChanges();
    };
    bar.appendChild(saveBtn);

    var discardBtn = document.createElement('button');
    discardBtn.className = 'discardButton';
    discardBtn.textContent = '↩️ Discard';
    discardBtn.onclick = function () {
        discardEditPanelChanges();
    };
    bar.appendChild(discardBtn);

    return bar;
}

function editPanel() {
    initEditState(false);
    renderEditPanelContent();
}

function renderEditPanelContent() {
    var prevScroll = schedule ? schedule.scrollTop : 0;
    if (!Panel || !schedule.contains(Panel)) {
        schedule.innerHTML = '';
        Panel = document.createElement('div');
        Panel.id = 'editPanel';
        schedule.appendChild(Panel);
    } else {
        Panel.innerHTML = '';
    }

    // Top Sticky Actions Bar
    Panel.appendChild(createEditActionsBar(false));

    var addTitle = function (text) {
        var t = document.createElement('h2');
        t.textContent = text;
        t.style.color = 'var(--text-main)';
        t.style.textAlign = 'center';
        t.style.margin = '6vmin 0 2vmin 0';
        t.style.fontSize = '4.5vmin';
        t.style.fontWeight = '500';
        Panel.appendChild(t);
    };

    var curTPersons = editState.tListUp || [];
    var curDPersons = editState.dListUp || [];
    var allNames = [];
    var nameSet = {};
    for (var ni = 0; ni < curTPersons.length; ni++) {
        if (!nameSet[curTPersons[ni]]) { nameSet[curTPersons[ni]] = true; allNames.push(curTPersons[ni]); }
    }
    for (var ni = 0; ni < curDPersons.length; ni++) {
        if (!nameSet[curDPersons[ni]]) { nameSet[curDPersons[ni]] = true; allNames.push(curDPersons[ni]); }
    }

    // 1. 🌴 Vacations
    addTitle('🌴 Vacations');
    var editvac = document.createElement('div');
    editvac.className = 'editvac';
    Panel.appendChild(editvac);

    var row = document.createElement('div');
    row.className = 'rowVac';
    editvac.appendChild(row);

    var addVac = document.createElement('select');
    var vacDropdownList = allNames.length > 0 ? allNames : curTPersons;
    vacDropdownList.forEach(function (item) {
        var vacName = document.createElement('option');
        vacName.value = item;
        vacName.textContent = item;
        addVac.appendChild(vacName);
    });
    row.appendChild(addVac);

    var dateInput = document.createElement('input');
    dateInput.type = 'date';
    dateInput.value = new Date().getFullYear() + '-' + cmonth + '-' + today;
    row.appendChild(dateInput);

    var daysInput = document.createElement('input');
    daysInput.type = 'number';
    daysInput.min = 1;
    daysInput.placeholder = 'Days';
    row.appendChild(daysInput);

    var tType = document.createElement('select');
    ['All', 'Dishes', 'Table'].forEach(function (v) {
        var taskName = document.createElement('option');
        taskName.value = v;
        taskName.textContent = v;
        tType.appendChild(taskName);
    });
    row.appendChild(tType);

    var addButton = document.createElement('button');
    addButton.textContent = 'Add';
    addButton.className = 'addVac';
    addButton.onclick = function () {
        var newVac = {
            Name: addVac.value,
            vacDay: new Date(dateInput.value).getTime() + offset,
            Days: parseInt(daysInput.value),
            taskType: tType.value
        };
        if (newVac.Name && !isNaN(newVac.vacDay) && !isNaN(newVac.Days) && newVac.Days > 0 && newVac.taskType) {
            editState.vacation.push(newVac);
            editDirty = true;
            nativeToast('Vacation added to draft (click Save to apply)');
            renderEditPanelContent();
        } else {
            nativeToast('Please fill all vacation fields correctly.');
        }
    };
    row.appendChild(addButton);

    for (var k = 0; k < editState.vacation.length; k++) {
        (function (key) {
            var value = editState.vacation[key];
            var newRow = document.createElement('div');
            newRow.className = 'newRow';

            var vacDiv = document.createElement('div');
            vacDiv.textContent = value.Name;
            newRow.appendChild(vacDiv);

            var dateDiv = document.createElement('div');
            dateDiv.textContent = new Date(value.vacDay).getDate() + '-' + (new Date(value.vacDay).getMonth() + 1) + '-' + new Date(value.vacDay).getFullYear();
            newRow.appendChild(dateDiv);

            var daysDiv = document.createElement('div');
            if (value.Days == 1) { daysDiv.textContent = value.Days + ' Day'; } else { daysDiv.textContent = value.Days + ' Days'; }
            newRow.appendChild(daysDiv);

            var taskTypeDiv = document.createElement('div');
            taskTypeDiv.textContent = value.taskType;
            newRow.appendChild(taskTypeDiv);

            var delButton = document.createElement('button');
            delButton.textContent = 'Delete';
            delButton.className = 'delete';
            delButton.onclick = function () {
                if (confirm('Delete vacation for ' + value.Name + '? (Draft only until you click Save)')) {
                    editState.vacation.splice(key, 1);
                    editDirty = true;
                    renderEditPanelContent();
                }
            };
            newRow.appendChild(delButton);
            editvac.appendChild(newRow);
        })(k);
    }

    // 2. 👥 Shift Workers Pool
    addTitle('👥 Shift Workers Pool');
    var ediPpl = document.createElement('div');
    ediPpl.className = 'ediPpl';
    ediPpl.id = 'ediPpl';
    Panel.appendChild(ediPpl);

    // Dishes pool
    var dPpl = document.createElement('div');
    dPpl.className = 'dPpl';
    dPpl.id = 'dPpl';
    ediPpl.appendChild(dPpl);

    var daRow = document.createElement('div');
    daRow.className = 'row';
    dPpl.appendChild(daRow);

    var daInput = document.createElement('input');
    daInput.type = 'text';
    daInput.placeholder = 'Dishes';
    daRow.appendChild(daInput);

    var daButton = document.createElement('button');
    daButton.textContent = 'Add';
    daButton.onclick = function () {
        if (daInput.value && daInput.value.trim()) {
            editState.dListUp.unshift(daInput.value.trim());
            editDirty = true;
            nativeToast('Added to dishes (draft)');
            renderEditPanelContent();
        } else {
            nativeToast('Please fill name field correctly.');
        }
    };
    daRow.appendChild(daButton);

    for (var k = 0; k < editState.dListUp.length; k++) {
        (function (key) {
            var value = editState.dListUp[key];
            var dRow = document.createElement('div');
            dRow.className = 'row';

            var dName = document.createElement('div');
            dName.textContent = value;
            dRow.appendChild(dName);

            var ddel = document.createElement('button');
            ddel.textContent = 'Delete';
            ddel.className = 'delete';
            ddel.onclick = function () {
                if (confirm('Remove ' + value + ' from dishes? (Draft only until you click Save)')) {
                    editState.dListUp.splice(key, 1);
                    editDirty = true;
                    renderEditPanelContent();
                }
            };
            dRow.appendChild(ddel);
            dPpl.appendChild(dRow);
        })(k);
    }

    // Table pool
    var tPpl = document.createElement('div');
    tPpl.className = 'tPpl';
    tPpl.id = 'tPpl';
    ediPpl.appendChild(tPpl);

    var taRow = document.createElement('div');
    taRow.className = 'row';
    tPpl.appendChild(taRow);

    var taInput = document.createElement('input');
    taInput.type = 'text';
    taInput.placeholder = 'Table';
    taRow.appendChild(taInput);

    var taButton = document.createElement('button');
    taButton.textContent = 'Add';
    taButton.onclick = function () {
        if (taInput.value && taInput.value.trim()) {
            editState.tListUp.unshift(taInput.value.trim());
            editDirty = true;
            nativeToast('Added to table duties (draft)');
            renderEditPanelContent();
        } else {
            nativeToast('Please fill name field correctly.');
        }
    };
    taRow.appendChild(taButton);

    for (var k = 0; k < editState.tListUp.length; k++) {
        (function (key) {
            var value = editState.tListUp[key];
            var tRow = document.createElement('div');
            tRow.className = 'row';

            var tName = document.createElement('div');
            tName.textContent = value;
            tRow.appendChild(tName);

            var tdel = document.createElement('button');
            tdel.textContent = 'Delete';
            tdel.className = 'delete';
            tdel.onclick = function () {
                if (confirm('Remove ' + value + ' from table duties? (Draft only until you click Save)')) {
                    editState.tListUp.splice(key, 1);
                    editDirty = true;
                    renderEditPanelContent();
                }
            };
            tRow.appendChild(tdel);
            tPpl.appendChild(tRow);
        })(k);
    }

    // 3. 🚫 Disable Specific Shifts
    addTitle('🚫 Disable Specific Shifts');
    var taskOff = document.createElement('div');
    taskOff.className = 'taskOff';
    Panel.appendChild(taskOff);

    var offAdd = document.createElement('div');
    offAdd.className = 'offRow';
    taskOff.appendChild(offAdd);

    var toffDate = document.createElement('input');
    toffDate.type = 'date';
    toffDate.value = new Date().getFullYear() + '-' + cmonth + '-' + today;
    offAdd.appendChild(toffDate);

    var toffType = document.createElement('select');
    ['All', 'Dishes', 'Table'].forEach(function (v) {
        var taskName = document.createElement('option');
        taskName.value = v;
        taskName.textContent = v;
        toffType.appendChild(taskName);
    });
    offAdd.appendChild(toffType);

    var toffText = document.createElement('input');
    toffText.type = 'text';
    toffText.placeholder = 'Custom text (Optional)';
    offAdd.appendChild(toffText);

    var toffButton = document.createElement('button');
    toffButton.textContent = 'Add';
    toffButton.className = 'toffButton';
    toffButton.onclick = function () {
        var newToff = {
            task: toffType.value,
            date: new Date(toffDate.value).getTime() + offset
        };
        if (toffText.value.trim()) {
            newToff.customText = toffText.value.trim();
        }
        if (newToff.task && !isNaN(newToff.date) && newToff.date > tsPast) {
            editState.toffList.push(newToff);
            editDirty = true;
            nativeToast('Task off rule added to draft');
            renderEditPanelContent();
        } else {
            nativeToast('Please fill all fields correctly.');
        }
    };
    offAdd.appendChild(toffButton);

    for (var k = 0; k < editState.toffList.length; k++) {
        (function (key) {
            var value = editState.toffList[key];
            var offRow = document.createElement('div');
            offRow.className = 'offRow';

            var dateDiv = document.createElement('div');
            dateDiv.textContent = new Date(value.date).getDate() + '-' + (new Date(value.date).getMonth() + 1) + '-' + new Date(value.date).getFullYear();
            offRow.appendChild(dateDiv);

            var taskTypeDiv = document.createElement('div');
            taskTypeDiv.textContent = value.task + (value.customText ? ' (' + value.customText + ')' : '');
            offRow.appendChild(taskTypeDiv);

            var delButton = document.createElement('button');
            delButton.textContent = 'Delete';
            delButton.className = 'delete';
            delButton.onclick = function () {
                if (confirm('Delete disabled shift rule? (Draft only until you click Save)')) {
                    editState.toffList.splice(key, 1);
                    editDirty = true;
                    renderEditPanelContent();
                }
            };
            offRow.appendChild(delButton);
            taskOff.appendChild(offRow);
        })(k);
    }

    // 4. ⏭️ Skip Worker Turn
    addTitle('⏭️ Skip Worker Turn');
    var skipSection = document.createElement('div');
    skipSection.className = 'taskOff';
    Panel.appendChild(skipSection);

    var skipAdd = document.createElement('div');
    skipAdd.className = 'offRow';
    skipSection.appendChild(skipAdd);

    var skipName = document.createElement('select');
    allNames.forEach(function (item) {
        var opt = document.createElement('option');
        opt.value = item;
        opt.textContent = item;
        skipName.appendChild(opt);
    });
    skipAdd.appendChild(skipName);

    var skipDate = document.createElement('input');
    skipDate.type = 'date';
    skipDate.value = new Date().getFullYear() + '-' + cmonth + '-' + today;
    skipAdd.appendChild(skipDate);

    var skipType = document.createElement('select');
    ['All', 'Dishes', 'Table'].forEach(function (v) {
        var opt = document.createElement('option');
        opt.value = v;
        opt.textContent = v;
        skipType.appendChild(opt);
    });
    skipAdd.appendChild(skipType);

    var skipBtn = document.createElement('button');
    skipBtn.textContent = 'Add Skip';
    skipBtn.className = 'toffButton';
    skipBtn.onclick = function () {
        var newSkip = { Name: skipName.value, taskType: skipType.value, skipDate: new Date(skipDate.value).getTime() + offset };
        if (newSkip.Name && !isNaN(newSkip.skipDate)) {
            editState.skipList.push(newSkip);
            editDirty = true;
            nativeToast('Added skip rule to draft');
            renderEditPanelContent();
        } else {
            nativeToast('Fill all fields!');
        }
    };
    skipAdd.appendChild(skipBtn);

    for (var k = 0; k < editState.skipList.length; k++) {
        (function (key) {
            var val = editState.skipList[key];
            var sRow = document.createElement('div');
            sRow.className = 'offRow';

            var nDiv = document.createElement('div'); nDiv.textContent = val.Name; sRow.appendChild(nDiv);
            var dDiv = document.createElement('div'); dDiv.textContent = new Date(val.skipDate).getDate() + '-' + (new Date(val.skipDate).getMonth() + 1); sRow.appendChild(dDiv);
            var tDiv = document.createElement('div'); tDiv.textContent = val.taskType; sRow.appendChild(tDiv);

            var delBtn = document.createElement('button');
            delBtn.textContent = 'Delete';
            delBtn.className = 'delete';
            delBtn.onclick = function () {
                if (confirm('Delete skip rule for ' + val.Name + '? (Draft only until you click Save)')) {
                    editState.skipList.splice(key, 1);
                    editDirty = true;
                    renderEditPanelContent();
                }
            };
            sRow.appendChild(delBtn);
            skipSection.appendChild(sRow);
        })(k);
    }

    // 5. 🎯 Force Manual Assignment
    addTitle('🎯 Force Manual Assignment');
    var manSection = document.createElement('div');
    manSection.className = 'taskOff';
    Panel.appendChild(manSection);

    var manAdd = document.createElement('div');
    manAdd.className = 'offRow';
    manSection.appendChild(manAdd);

    var manName = document.createElement('select');
    allNames.forEach(function (item) {
        var opt = document.createElement('option');
        opt.value = item;
        opt.textContent = item;
        manName.appendChild(opt);
    });
    manAdd.appendChild(manName);

    var manDate = document.createElement('input');
    manDate.type = 'date';
    manDate.value = new Date().getFullYear() + '-' + cmonth + '-' + today;
    manAdd.appendChild(manDate);

    var manType = document.createElement('select');
    ['Dishes', 'Table'].forEach(function (v) {
        var opt = document.createElement('option');
        opt.value = v;
        opt.textContent = v;
        manType.appendChild(opt);
    });
    manAdd.appendChild(manType);

    var manBtn = document.createElement('button');
    manBtn.textContent = 'Assign';
    manBtn.className = 'toffButton';
    manBtn.onclick = function () {
        var newMan = { Name: manName.value, taskType: manType.value, mDate: new Date(manDate.value).getTime() + offset };
        if (newMan.Name && !isNaN(newMan.mDate)) {
            editState.mList.push(newMan);
            editDirty = true;
            nativeToast('Manual assignment added to draft');
            renderEditPanelContent();
        } else {
            nativeToast('Fill all fields!');
        }
    };
    manAdd.appendChild(manBtn);

    for (var k = 0; k < editState.mList.length; k++) {
        (function (key) {
            var val = editState.mList[key];
            var mRow = document.createElement('div');
            mRow.className = 'offRow';

            var nDiv = document.createElement('div'); nDiv.textContent = val.Name; mRow.appendChild(nDiv);
            var dDiv = document.createElement('div'); dDiv.textContent = new Date(val.mDate).getDate() + '-' + (new Date(val.mDate).getMonth() + 1); mRow.appendChild(dDiv);
            var tDiv = document.createElement('div'); tDiv.textContent = val.taskType; mRow.appendChild(tDiv);

            var delBtn = document.createElement('button');
            delBtn.textContent = 'Delete';
            delBtn.className = 'delete';
            delBtn.onclick = function () {
                if (confirm('Delete manual assignment for ' + val.Name + '? (Draft only until you click Save)')) {
                    editState.mList.splice(key, 1);
                    editDirty = true;
                    renderEditPanelContent();
                }
            };
            mRow.appendChild(delBtn);
            manSection.appendChild(mRow);
        })(k);
    }

    // 6. 💾 System Backup
    addTitle('💾 System Backup');
    var backupSection = document.createElement('div');
    backupSection.className = 'taskOff';
    Panel.appendChild(backupSection);

    var backupTitle = document.createElement('div');
    backupTitle.textContent = 'Database Backup & Restore';
    backupTitle.style.color = 'var(--text-muted)';
    backupTitle.style.marginBottom = '1vmin';
    backupTitle.style.textAlign = 'center';
    backupSection.appendChild(backupTitle);

    var backupRow = document.createElement('div');
    backupRow.className = 'offRow';
    backupRow.style.justifyContent = 'center';
    backupRow.style.gap = '2vmin';
    backupSection.appendChild(backupRow);

    var exportBtn = document.createElement('button');
    exportBtn.textContent = 'Export Backup';
    exportBtn.className = 'toffButton';
    exportBtn.style.padding = '1.5vmin 3vmin';
    exportBtn.onclick = function () {
        var backupData = JSON.stringify(editDirty ? editState : state, null, 2);
        var dateStr = new Date().toISOString().split('T')[0];
        var filename = 'cleanshift_backup_' + dateStr + '.json';
        if (window.AndroidSave) {
            window.AndroidSave.saveFile(filename, backupData);
        } else {
            var blob = new Blob([backupData], { type: 'application/json' });
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            a.download = filename;
            a.click();
            URL.revokeObjectURL(url);
        }
    };
    backupRow.appendChild(exportBtn);

    var importFile = document.createElement('input');
    importFile.type = 'file';
    importFile.accept = '.json,application/json';
    importFile.style.display = 'none';
    importFile.onchange = function (e) {
        var file = e.target.files[0];
        if (!file) return;
        var reader = new FileReader();
        reader.onload = function (e) {
            window.loadImportedJSON(e.target.result);
        };
        reader.readAsText(file);
    };
    backupRow.appendChild(importFile);

    var importBtn = document.createElement('button');
    importBtn.textContent = 'Import Backup';
    importBtn.className = 'toffButton';
    importBtn.style.padding = '1.5vmin 3vmin';
    importBtn.style.background = 'transparent';
    importBtn.style.border = '1px solid var(--glass-border)';
    importBtn.onclick = function () {
        if (window.AndroidSave) {
            window.AndroidSave.loadFile();
        } else {
            importFile.click();
        }
    };
    backupRow.appendChild(importBtn);

    // OTA Web Updates Section in Settings
    var otaTitle = document.createElement('div');
    otaTitle.textContent = 'OTA Web Updates (تحديثات الواجهة المباشرة)';
    otaTitle.style.color = 'var(--text-muted)';
    otaTitle.style.marginTop = '2.5vmin';
    otaTitle.style.marginBottom = '1vmin';
    otaTitle.style.textAlign = 'center';
    backupSection.appendChild(otaTitle);

    var otaRow = document.createElement('div');
    otaRow.className = 'offRow';
    otaRow.style.justifyContent = 'center';
    otaRow.style.gap = '2vmin';
    backupSection.appendChild(otaRow);

    var checkOtaBtn = document.createElement('button');
    var wVer = 0;
    try {
        if (window.AndroidNative && window.AndroidNative.getInstalledWebVersion) {
            wVer = window.AndroidNative.getInstalledWebVersion();
        }
    } catch(e) {}
    checkOtaBtn.textContent = 'Check Web Updates' + (wVer > 0 ? ' (v' + wVer + ')' : '');
    checkOtaBtn.className = 'toffButton';
    checkOtaBtn.style.padding = '1.5vmin 2.5vmin';
    checkOtaBtn.onclick = function () {
        if (window.AndroidNative && window.AndroidNative.checkForUpdatesManually) {
            window.AndroidNative.checkForUpdatesManually();
        } else {
            nativeToast('Available on Android app.');
        }
    };
    otaRow.appendChild(checkOtaBtn);

    var resetOtaBtn = document.createElement('button');
    resetOtaBtn.textContent = 'Reset to Factory Assets';
    resetOtaBtn.className = 'toffButton';
    resetOtaBtn.style.padding = '1.5vmin 2.5vmin';
    resetOtaBtn.style.background = 'transparent';
    resetOtaBtn.style.border = '1px solid var(--glass-border)';
    resetOtaBtn.onclick = function () {
        if (confirm('هل تريد حذف تحديثات الويب والعودة إلى ملفات APK الأصلية؟\n(Revert to original built-in assets?)')) {
            if (window.AndroidNative && window.AndroidNative.resetToOriginalVersion) {
                window.AndroidNative.resetToOriginalVersion();
            } else {
                nativeToast('Available on Android app.');
            }
        }
    };
    otaRow.appendChild(resetOtaBtn);

    // Bottom Actions Bar
    Panel.appendChild(createEditActionsBar(true));

    if (schedule && prevScroll > 0) {
        schedule.scrollTop = prevScroll;
    }
}

window.loadImportedJSON = function(jsonStr) {
    try {
        var importedState = JSON.parse(jsonStr);
        if (importedState && (importedState.dListUp || importedState.dishesPeople)) {
            if (confirm('Load imported backup into draft? Click "Save Changes" to commit and update app.')) {
                editState = clone(importedState);
                normalizeEditState();
                editDirty = true;
                renderEditPanelContent();
                nativeToast('Backup loaded into draft! Review and click Save Changes.');
            }
        } else {
            nativeToast('Invalid backup file format.');
        }
    } catch (err) { nativeToast('Failed to parse backup file.'); }
};

function saveState() {
    database.ref('state/').set(state);
    saveCache(JSON.stringify(state));
    renderAll();
    syncWidget();
    nativeToast('Schedule changes saved successfully!');
    if (show === 'edi') {
        initEditState(true);
        renderEditPanelContent();
    }
}

function sendData() {// send data
    if (savedDate.getTime() < datePast.getTime()) {
        let h = (tsPast - tsSavedDate) / msDay;
        for (let i = 0; i < h; i++) {
            let hDate = tsSavedDate + i * msDay;
            if (shiftType(hDate) < 4) {
                state.history[hDate] = whoWork(hDate);
            }
        };
        state.savedDate = tsPast;
        let ref = database.ref('/');
        ref.set({ state });
        saveCache(JSON.stringify(state));
    };

    for (let key in state.vacation) {
        let value = state.vacation[key];
        if (value.vacDay + value.Days * msDay < tsSavedDate) {
            database.ref('state/vacation/' + key).remove();
            goEditPanel();
        }
    }

    for (let key in state.toffList) {
        let value = state.toffList[key];
        if (value.date < tsSavedDate) {
            database.ref('state/toffList/' + key).remove();
            goEditPanel();
        }
    }
};

renderAll();
scrollToday();
updateNavButtons();
fetch2();

// Global Scroll Forwarding for Calendar
let _touchStartY = 0;
document.addEventListener('touchstart', function (e) {
    _touchStartY = e.touches[0].clientY;
}, { passive: true });

document.addEventListener('touchmove', function (e) {
    if ((show === 'cal' || show === 'work') && !e.target.closest('#schedule')) {
        let schedule = document.getElementById('schedule');
        let currentY = e.touches[0].clientY;
        schedule.scrollTop += (_touchStartY - currentY);
        _touchStartY = currentY;
    }
}, { passive: true });

document.addEventListener('wheel', function (e) {
    if ((show === 'cal' || show === 'work') && !e.target.closest('#schedule')) {
        let schedule = document.getElementById('schedule');
        schedule.scrollTop += e.deltaY;
    }
}, { passive: true });